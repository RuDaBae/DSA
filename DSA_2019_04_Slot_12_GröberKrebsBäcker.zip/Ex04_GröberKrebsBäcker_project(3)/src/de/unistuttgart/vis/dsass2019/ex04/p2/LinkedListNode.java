package de.unistuttgart.vis.dsass2019.ex04.p2;

public class LinkedListNode<T extends Comparable<T>> implements ILinkedListNode<T>{

	T elem;
	public ILinkedListNode<T> nextElem;
	public ILinkedListNode<T> prevElem;
	
	public LinkedListNode()
	{
	}
	
	@Override
	public T getElement()
	{
		return elem;
	}

	@Override
	public void setElement(T element)
	{
		elem = element;
	}

	@Override
	public ILinkedListNode<T> getNext()
	{
		return nextElem;
	}

	@Override
	public void setNext(ILinkedListNode<T> next)
	{
		this.nextElem = next;
		
	}

	@Override
	public ILinkedListNode<T> getPrev()
	{
		return prevElem;
	}

	@Override
	public void setPrev(ILinkedListNode<T> prev)
	{
		this.prevElem = prev;
		
	}


}
