package de.unistuttgart.vis.dsass2019.ex04.p2;

public class CircularLinkedList<T extends Comparable<T>> implements
		ICircularLinkedList<T> 
{
	ILinkedListNode<T> head = null;
	ILinkedListNode<T> tail = null;

	public CircularLinkedList()
	{
		this.head.setPrev(null);
		this.head.setNext(tail);
		
		this.tail.setElement(null);
		this.tail.setPrev(tail);
	}
	
	@Override
	public void append(T element)
	{
		if(head == null)
		{
			head = new LinkedListNode<T>();
			head.setElement(element);
			head.setNext(null);
			head.setPrev(null);
			head = tail;
		}else
		{
			head = new LinkedListNode<T>();
			head.setElement(element);
			head.setNext(null);
			head.setPrev(tail);
			head.getPrev().setNext(head);
		}
	}

	@Override
	public T get(int index)
	{
		ILinkedListNode<T> element =  head;
		
		//handle negative numbers
		while(index<0)
		{
			index += size();
			index++;
		}
		
		//reduce index to actual of list
		while(index >size())
		{
			index -= index;
		}
		
		for(int i = 0; i < index; i++)
		{
			element = element.getNext();
		}
		return (T) element;
	}

	@Override
	public int size()
	{
		int i = 0;
		ILinkedListNode<T> element = head;
		while(element != tail)
		{
			i++;
			element = element.getNext();
		}
		return i++;
	}

	@Override
	public ILinkedListNode<T> getHead()
	{
		return head;
	}


}
